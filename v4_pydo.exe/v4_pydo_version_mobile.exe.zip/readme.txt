TOUT_DOUX_LISTE version 4


C'est la version exécutable de la version 3, avec une base de donnée SQLite. Il a été transformé en exécutable grâce à Pyinstaller.


Le programme fonctionne en exécutable. Vous n'avez rien à installer, juste lancer l'application. Lors du lancement de l'application, une base de donnée 'todolist.db' va se créer dans le dossier.

Si vous désirez avoir accès a la base de donnée via une interface graphique, vous pouvez utilisé le logiciel 'DB Browser(sqlite)'.